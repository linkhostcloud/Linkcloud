# SEJA BEM VINDO(A)! 🤝

# SSH-PLUS

# @swittecnologia

*PROJETO EM ANDAMENTO...


# Modo de instalação
# 👇😎👍
Só joga na máquina e deixar instalar

• atualiza sistema

• desativa Ipv6

• instala recursos e o script
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/JeanRocha91x/SSHPLUS/main/ssh-plus)

```
<div align="left">
<img src="https://user-images.githubusercontent.com/105602625/177037521-9c79ed5f-c56d-42b8-8ebf-58dd8f63566f.jpg" width="350px" /></br>
<img src="https://user-images.githubusercontent.com/105602625/177037522-4dd14720-d0d0-4416-bc0c-9ef6d7891538.jpg" width="350px" /></br>
<img src="https://user-images.githubusercontent.com/105602625/177037524-8aa985ad-47d0-4f3e-aa97-4b2052436f6b.jpg" width="350px" /></br>
<img src="https://user-images.githubusercontent.com/105602625/177037525-8c621136-2fae-4a5e-b894-40e552b1edc1.jpg" width="350px" /></br>
</div>
